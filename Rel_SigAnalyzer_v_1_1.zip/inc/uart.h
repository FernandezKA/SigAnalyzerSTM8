#ifndef _uart_h_
#define _uart_h_
#include "general.h"
#ifdef DEBUG
void Print(uint8_t data);
void vUart_Config(void);
#endif

#endif